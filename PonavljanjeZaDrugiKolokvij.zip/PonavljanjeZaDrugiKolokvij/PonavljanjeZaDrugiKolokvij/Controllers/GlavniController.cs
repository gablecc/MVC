﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace PonavljanjeZaDrugiKolokvij.Controllers
{
    public class GlavniController : Controller
    {
        public IActionResult Pocetna()
        {
            return View();
        }

        public IActionResult datumi(string prvi, string drugi)
        {
            HttpContext.Session.SetString(prvi, drugi);
            var unos = DateTime.TryParse(prvi, out DateTime Prvi);
            unos = DateTime.TryParse(drugi, out DateTime Drugi);

            var rez = Drugi - Prvi;

            if (Prvi > Drugi)
            {
                ViewBag.rezultat = "Pogrešan unos";
            }
            else
            {
                ViewBag.rezultat = rez;
            }
            HttpContext.Session.SetString("Prvi", Prvi.ToString());
            HttpContext.Session.SetString("Drugi", Drugi.ToString());
            return View("Pocetna");
        }

        public IActionResult Sesija()
        {
            return View();
        }
    }
}
