﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using System.IO;

namespace TreciZadatak.Controllers
{
    public class GlavniController : Controller
    {
        public IActionResult Pocetna()
        { 
            return View();
        }

        public IActionResult Upload(IFormFile datoteka)
        {
            DirectoryInfo dir = new DirectoryInfo(Environment.CurrentDirectory + "\\Datoteke");
            if (dir.GetFiles().Length < 3)
            {
                string putanja = Environment.CurrentDirectory + "\\Datoteke\\" + datoteka.FileName;
                FileStream file = new FileStream(putanja, FileMode.Create);
                datoteka.CopyTo(file);
                file.Close();
            }
            else
            {
                ViewBag.poruka = "Samo 3 datoteke";
            }
            string[] popisDatoteka = dir.GetFiles().Select(file => file.Name).ToArray();
            ViewBag.brojac = popisDatoteka;

            return RedirectToAction("Pocetna");
        }
    }
}
