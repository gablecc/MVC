﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace PrviZadatak.Models
{
    public class Adresar
    {
        internal static DataTable dohvatiKontakte()
        {
            DataTable podaci = new DataTable();
            SqlConnection konekcija = new SqlConnection(Startup.konekcijskiString);
            try
            {
                SqlDataAdapter naredba = new SqlDataAdapter("SELECT Ime, Prezime, Mail FROM Kontakti", konekcija);
                naredba.Fill(podaci);
            }
            catch { }
            finally
            {
                konekcija.Close();
            }
            return podaci;
        }
    }
}
