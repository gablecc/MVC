﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using System.Data;
using PrviZadatak.Models;


namespace PrviZadatak.Controllers
{
    public class GlavniController : Controller
    {
       

        public IActionResult Pocetna()
        {
            DataTable podaci = Adresar.dohvatiKontakte();
            ViewBag.rezultat = podaci;
            return View("Pocetna");
        }
    }
}
